package com.example.lumina_mobile_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
