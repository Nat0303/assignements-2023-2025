import 'student_quiz_qr_scanner.dart';
import 'package:flutter/material.dart';
import 'db/supabase_service.dart';
import 'student_attempt_quiz.dart';

class StudentQuizListScreen extends StatefulWidget {
  final String studentId;

  const StudentQuizListScreen({
    super.key,
    required this.studentId,
  });

  @override
  State<StudentQuizListScreen> createState() => _StudentQuizListScreenState();
}

class _StudentQuizListScreenState extends State<StudentQuizListScreen> {
  Key _refreshKey = UniqueKey();

  final TextEditingController _searchController = TextEditingController();
  String searchQuery = "";

  void _showEnterQuizDialog(BuildContext context) {
    final TextEditingController _quizController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              const Text(
                "Enter Quiz ID",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 10),

              const Text(
                "Input your quiz code to join",
                style: TextStyle(color: Colors.grey),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 10),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF005A9C),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  icon: const Icon(Icons.qr_code_scanner, color: Colors.white),
                  label: const Text(
                    "Scan QR Code",
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () async {
                    Navigator.pop(context);

                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => StudentQRScannerScreen(
                          studentId: widget.studentId, // ✅ PASS THIS
                        ),
                      ),
                    );

                    if (result != null) {
                      final quiz = await SupabaseService.getQuizById(result);

                      if (quiz == null) {
                        _showStatusSnackbar(
                          "Not Found",
                          "Invalid QR Code",
                          false,
                        );
                        return;
                      }

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => StudentAttemptQuizScreen(
                            quizId: result,
                            quizTitle: quiz['title'],
                            studentId: widget.studentId,
                          ),
                        ),
                      );
                    }
                  },
                ),
              ),

              const SizedBox(height: 20),

              //INPUT FIELD
              TextField(
                controller: _quizController,
                textAlign: TextAlign.center,
                maxLength: 12,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                ),
                decoration: InputDecoration(
                  hintText: "e.g. 123456",
                  counterText: "",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),

                  //SEND BUTTON
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.send,
                        color: Color(0xFF005A9C)),
                    onPressed: () async {
                      final id = _quizController.text.trim();

                      if (id.isEmpty) return;

                      final quiz = await SupabaseService.getQuizById(id);

                      if (quiz == null) {
                        Navigator.pop(context);

                        _showStatusSnackbar(
                          "Not Found",
                          "Quiz ID does not exist",
                          false,
                        );
                        return;
                      }

                      Navigator.pop(context);

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => StudentAttemptQuizScreen(
                            quizId: id,
                            quizTitle: quiz['title'],
                            studentId: widget.studentId,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

              const SizedBox(height: 10),

              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showStatusSnackbar(String title, String message, bool isSuccess) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: isSuccess ? Colors.green : Colors.red,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(
                isSuccess ? Icons.check_circle : Icons.error,
                color: Colors.white,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "$title\n$message",
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F6F9),

      body: Column(
        children: [
          // ===== HEADER =====
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 60, 20, 20),
            decoration: const BoxDecoration(
              color: Color(0xFF005A9C),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(35),
                bottomRight: Radius.circular(35),
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    // 🔙 Back
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.arrow_back_ios_new_rounded,
                            color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ),

                    const SizedBox(width: 10),

                    const CircleAvatar(
                      backgroundColor: Colors.white,
                      child: Icon(Icons.quiz, color: Color(0xFF005A9C)),
                    ),

                    const SizedBox(width: 12),

                    const Expanded(
                      child: Text(
                        "Available Quizzes",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.qr_code, color: Colors.white),
                      tooltip: 'Enter Quiz ID',
                      onPressed: () => _showEnterQuizDialog(context),
                    ),
                    IconButton(
                      icon: const Icon(Icons.refresh, color: Colors.white),
                      onPressed: () {
                        setState(() {
                          _refreshKey = UniqueKey();
                          _searchController.clear();
                          searchQuery = "";
                        });
                      },
                    ),
                  ],
                ),

                const SizedBox(height: 15),

                // 🔍 SEARCH BAR
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: TextField(
                    controller: _searchController,
                    onChanged: (value) {
                      setState(() {
                        searchQuery = value.toLowerCase();
                      });
                    },
                    decoration: const InputDecoration(
                      hintText: "Search quiz title...",
                      prefixIcon: Icon(Icons.search),
                      border: InputBorder.none,
                      contentPadding:
                      EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ===== QUIZ LIST =====
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              key: _refreshKey,
              future: SupabaseService.client
                  .from('quizzes')
                  .select()
                  .order('created_at', ascending: false),
              builder: (context, snapshot) {
                if (snapshot.connectionState ==
                    ConnectionState.waiting) {
                  return const Center(
                      child: CircularProgressIndicator());
                }

                if (snapshot.hasError) {
                  return Center(
                      child: Text('Error: ${snapshot.error}'));
                }

                final rows = snapshot.data ?? [];

                // 🔥 FILTER LOGIC
                final filtered = rows.where((quiz) {
                  final title =
                  (quiz['title'] ?? "").toString().toLowerCase();
                  return title.contains(searchQuery);
                }).toList();

                if (filtered.isEmpty) {
                  return const Center(
                    child: Text(
                      'No matching quizzes found.',
                      style: TextStyle(fontSize: 16),
                    ),
                  );
                }

                return RefreshIndicator(
                  onRefresh: () async {
                    setState(() {
                      _refreshKey = UniqueKey();
                      _searchController.clear();
                      searchQuery = "";
                    });
                  },
                  child: ListView.builder(
                    padding: const EdgeInsets.all(20),
                    itemCount: filtered.length,
                    itemBuilder: (context, i) {
                      final quiz = filtered[i];

                      final String quizId = quiz['id'] ?? "";
                      final String title =
                          quiz['title'] ?? "Untitled Quiz";
                      final String topic =
                          quiz['topic'] ?? "General";
                      final int duration =
                          quiz['duration'] ?? 0;

                      return Container(
                        margin: const EdgeInsets.only(bottom: 15),
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color:
                              Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(18),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    StudentAttemptQuizScreen(
                                      quizId: quizId,
                                      quizTitle: title,
                                      studentId:
                                      widget.studentId,
                                    ),
                              ),
                            );
                          },
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF005A9C)
                                      .withOpacity(0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.play_arrow_rounded,
                                  color: Color(0xFF005A9C),
                                  size: 28,
                                ),
                              ),

                              const SizedBox(width: 15),

                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      title,
                                      style: const TextStyle(
                                        fontWeight:
                                        FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    const SizedBox(height: 5),

                                    Row(
                                      children: [
                                        const Icon(Icons.category,
                                            size: 14,
                                            color: Colors.grey),
                                        const SizedBox(width: 4),
                                        Text(topic,
                                            style:
                                            const TextStyle(
                                                color: Colors
                                                    .grey)),
                                      ],
                                    ),

                                    const SizedBox(height: 4),

                                    Row(
                                      children: [
                                        const Icon(Icons.timer,
                                            size: 14,
                                            color: Colors.grey),
                                        const SizedBox(width: 4),
                                        Text(
                                            "$duration mins",
                                            style:
                                            const TextStyle(
                                                color: Colors
                                                    .grey)),
                                      ],
                                    ),
                                  ],
                                ),
                              ),

                              const Icon(Icons.arrow_forward_ios,
                                  size: 16, color: Colors.grey),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}